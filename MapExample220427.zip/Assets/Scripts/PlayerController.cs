using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [SerializeField] private CharacterController player;
    [SerializeField] private Transform cam;
    [SerializeField] private float speed;

    private float angleX;
    private float angleY;

    float horizontal;
    float vertical;
    float gravityY;
    private Vector3 moveDir;

    private void Update()
    {
        PlayerMove();
        PlayerRotate();
        PlayerShoot();
    }

    private void Awake()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    private void PlayerMove()
    {
        if (player.isGrounded)
        {
            horizontal = Input.GetAxis("Horizontal");
            vertical = Input.GetAxis("Vertical");
            if (Input.GetKey(KeyCode.Space))
            {
                gravityY = 6f;
            }
        }
        else
        {
            gravityY += Physics.gravity.y * Time.deltaTime;
        }

        moveDir = new Vector3(horizontal, 0, vertical);

        if (moveDir.magnitude > 1)
        {
            moveDir.Normalize();
        }

        moveDir *= speed;
        moveDir.y = gravityY;

        player.Move(Quaternion.Euler(new Vector3(0, angleY, 0)) * moveDir * Time.deltaTime);

        if (Input.GetKey(KeyCode.LeftControl))
        {
            speed = 10;
        }
        else if (Input.GetKey(KeyCode.LeftShift))
        {
            speed = 2;
        }
        else
        {
            speed = 5;
        }
    }

    private void PlayerRotate()
    {
        angleX -= Input.GetAxis("Mouse Y");
        angleY += Input.GetAxis("Mouse X");

        cam.position = player.transform.position;
        cam.rotation = Quaternion.Euler(angleX, angleY, 0);
    }

    private void PlayerShoot()
    {
        Ray ray = Camera.main.ScreenPointToRay(new Vector2(Screen.width / 2, Screen.height / 2));
        if (Input.GetMouseButtonDown(0))
        {
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                if (hit.collider.gameObject.name == "Target")
                {
                    Destroy(hit.collider.gameObject);
                }
            }
        }

        
    }

   
}
